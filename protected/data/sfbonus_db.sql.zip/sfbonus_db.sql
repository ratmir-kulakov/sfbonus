-- phpMyAdmin SQL Dump
-- version 3.3.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Дек 03 2012 г., 22:30
-- Версия сервера: 5.0.45
-- Версия PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `sfbonus_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bkz_user`
--

CREATE TABLE IF NOT EXISTS `bkz_user` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `type` tinyint(2) unsigned NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `middle_name` varchar(40) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `last_login_time` int(10) unsigned NOT NULL default '0',
  `status` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `bkz_user`
--

INSERT INTO `bkz_user` (`id`, `type`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `last_login_time`, `status`) VALUES
(1, 1, '', '', '', 'admin', 'CjlaVfarCezlceUdrzraaDVcbrjCVzjz', 1354556861, 1);
