-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 24 2013 г., 22:43
-- Версия сервера: 5.1.67-community-log
-- Версия PHP: 5.3.20

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `sfbonus_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bkz_menu_items`
--

CREATE TABLE IF NOT EXISTS `bkz_menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `menu_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(64) NOT NULL,
  `route` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `bkz_page`
--

CREATE TABLE IF NOT EXISTS `bkz_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `last_update_date` int(10) unsigned NOT NULL,
  `created_date` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Таблица предназначена для хранения содержимого статических с' AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `bkz_page`
--

INSERT INTO `bkz_page` (`id`, `name`, `content`, `meta_title`, `meta_description`, `meta_keywords`, `last_update_date`, `created_date`, `status`) VALUES
(1, 'Как стать участником программы', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1360400226, 1358090001, 1),
(5, 'Как стать партнером', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1358099191, 1358091251, 1),
(6, 'Правила пользования картой', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1358099191, 1358094051, 1),
(7, 'Как получить максимальную выгоду', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1358099191, 1358096501, 1),
(8, 'Об организаторах', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1358099191, 1358096871, 1),
(9, 'Контакты', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1358100510, 1358098001, 1),
(10, 'О программе', '<p>Страница на стадии разработки.</p>\r\n', '', '', '', 1358100128, 1358099191, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `bkz_partner`
--

CREATE TABLE IF NOT EXISTS `bkz_partner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `conditions` text NOT NULL,
  `description` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `last_update_date` int(10) unsigned NOT NULL,
  `created_date` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `bkz_partner`
--

INSERT INTO `bkz_partner` (`id`, `name`, `conditions`, `description`, `meta_title`, `meta_description`, `meta_keywords`, `last_update_date`, `created_date`, `status`) VALUES
(1, 'Кофейня "З&М"', '<p><strong>20 баллов &nbsp;за каждые 100 рублей</strong> &ndash; Блюда японской кухни</p>\r\n\r\n<p><strong>15 баллов за каждые 100 рублей</strong> &ndash; Десерт</p>\r\n', '<p>&quot;З&amp;М&quot; &ndash; это продолжение лучших старинных кофейных традиций, благодаря чему наши гости каждый раз погружаются в атмосферу изысканного аромата и маленького праздника вкуса. Всех наших клиентов объединяет одно &ndash; любовь к настоящему кофе, которым можно не только насладиться в уютных и гостеприимных залах кофеен&nbsp;&quot;З&amp;М&quot;, но и взять с собой.</p>\r\n', '', '', '', 1360411641, 1360411452, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `bkz_partner_offices`
--

CREATE TABLE IF NOT EXISTS `bkz_partner_offices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` int(10) unsigned NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `schedule` varchar(255) NOT NULL,
  `ymaps_id` varchar(255) DEFAULT NULL,
  `ymaps_type` varchar(20) DEFAULT NULL,
  `cgeopoint_x` float(9,6) NOT NULL DEFAULT '0.000000',
  `cgeopoint_y` float(9,6) NOT NULL DEFAULT '0.000000',
  `geopoint_x` float(9,6) NOT NULL DEFAULT '0.000000',
  `geopoint_y` float(9,6) NOT NULL DEFAULT '0.000000',
  `status` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `partner_id` (`partner_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `bkz_partner_offices`
--

INSERT INTO `bkz_partner_offices` (`id`, `partner_id`, `address`, `phone`, `schedule`, `ymaps_id`, `ymaps_type`, `cgeopoint_x`, `cgeopoint_y`, `geopoint_x`, `geopoint_y`, `status`) VALUES
(1, 1, 'г. Махачкала, пр-т Р. Гамзатова, 95', '(8722) 65-43-21, 65-43-22', '<p>Понедельник-Воскресенье</p><p>10:00 - 23:00</p>', '', '', 0.000000, 0.000000, 0.000000, 0.000000, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `bkz_user`
--

CREATE TABLE IF NOT EXISTS `bkz_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) unsigned NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `middle_name` varchar(40) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `bkz_user`
--

INSERT INTO `bkz_user` (`id`, `type`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `last_login_time`, `status`) VALUES
(1, 1, '', '', '', 'admin', 'CjlaVfarCezlceUdrzraaDVcbrjCVzjz', 1361700793, 1),
(5, 2, '', '', '', 'moderator', 'CjlaVfarCezlceUdrzraaDVcbrjCVzjz', 1361638080, 1);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `bkz_partner_offices`
--
ALTER TABLE `bkz_partner_offices`
  ADD CONSTRAINT `bkz_partner_offices_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `bkz_partner` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
